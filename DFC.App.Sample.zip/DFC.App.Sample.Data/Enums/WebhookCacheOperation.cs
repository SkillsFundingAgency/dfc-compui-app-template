﻿namespace $safeprojectname$.Enums
{
    public enum WebhookCacheOperation
    {
        None,
        CreateOrUpdate,
        Delete,
    }
}
