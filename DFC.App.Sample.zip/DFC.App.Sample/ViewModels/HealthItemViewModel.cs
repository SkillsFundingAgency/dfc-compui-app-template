﻿using System.Diagnostics.CodeAnalysis;

namespace $safeprojectname$.ViewModels
{
    [ExcludeFromCodeCoverage]
    public class HealthItemViewModel
    {
        public string? Service { get; set; }

        public string? Message { get; set; }
    }
}
