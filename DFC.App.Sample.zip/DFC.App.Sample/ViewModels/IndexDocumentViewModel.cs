﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace $safeprojectname$.ViewModels
{
    [ExcludeFromCodeCoverage]
    public class IndexDocumentViewModel
    {
        public Guid? Id { get; set; }

        public string? Title { get; set; }
    }
}
